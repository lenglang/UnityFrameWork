﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

/// <summary>
/// 作者:siki
/// 微信公众账号：devsiki
/// QQ:804632564
/// 请关注微信公众号，关注最新的视频和文章教程信息！O(∩_∩)O
/// </summary>
namespace _014_反射和特性 {
    class MyClass
    {
        private int id;
        private int age;
        public int number;
        public string Name { get; set; }
        public string Name2 { get; set; }
        public string Name3 { get; set; }

        public void Test1() {

        }
        public void Test2() {

        }
    }
}
